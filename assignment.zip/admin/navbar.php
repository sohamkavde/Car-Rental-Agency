
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: coral;">
  <div class="container-fluid d-flex justify-space-between">
    <a class="navbar-brand" href="#"><h1 style="text-wrap: wrap;">Welcome to Admin Dashboard (<?php echo $_SESSION['Username'];?>)</h1></a>
    <a href="../logout.php" style="background-color: brown;color:#fff; padding:5px 10px;text-decoration:none;">logout</a>
  </div>
</nav>