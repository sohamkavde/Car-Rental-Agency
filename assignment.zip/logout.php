<?php
session_start();

session_destroy();


?>
<script>
    // home page rediration
    window.location.href = 'index.php';
</script>
<?php
?>